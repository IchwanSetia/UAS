tailwind.config = {
  theme: {
    extend: {
      colors: {
        primary: '#FF994F',
        secondary: '#FFFAF2',
        header: '#F6F9FC',
        footer: '#281900',
        fontColor: '#636363',
        three: '#F7FBFA',
      },
    },
  },
};
